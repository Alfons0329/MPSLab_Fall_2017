#!/bin/bash
cd ~/Ac6/SystemWorkbench && ./eclipse
